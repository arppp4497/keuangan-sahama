# Stock Journal & Financial Tracker

Mobile-first PWA untuk pencatatan investasi/trading saham.

## Jalankan
1. Install Node.js 18+.
2. Buka folder project.
3. Jalankan `npm install`.
4. Jalankan `npm run dev`.
5. Buka alamat Vite dari HP yang berada di jaringan Wi-Fi yang sama, atau gunakan `npm run dev -- --host 0.0.0.0`.

## Build
`npm run build`

## Catatan
- Data tersimpan di localStorage.
- Ada backup/import JSON.
- PWA memiliki manifest dan service worker.
- Harga pasar tidak diambil otomatis; aplikasi ini adalah jurnal/financial tracker, bukan pemberi sinyal beli/jual.
- Export CSV/Excel/PDF masih dapat ditambahkan sebagai modul berikutnya; backup JSON sudah tersedia pada versi ini.
