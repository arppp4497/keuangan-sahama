export type TxType="BUY"|"SELL";
export type Transaction={id:string;date:string;code:string;name:string;price:number;lots:number;fee:number;tax:number;other:number;reason:string;strategy:string;note:string;type:TxType};
export type Dividend={id:string;date:string;code:string;perShare:number;shares:number;tax:number};
export type Journal={id:string;date:string;code:string;buyReason:string;sellReason:string;target:string;stop:string;timeframe:string;strategy:string;market:string;feeling:string;result:string;mistake:string;lesson:string;rating:number};
export type Watch={id:string;code:string;target:string;stop:string;status:string;note:string};
export type AppData={transactions:Transaction[];dividends:Dividend[];journals:Journal[];watchlist:Watch[];cash:number;theme:"light"|"dark";target:number};